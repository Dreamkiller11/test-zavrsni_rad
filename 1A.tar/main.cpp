#include "mbed.h"
#include "millis.h" // Biblioteka za tajmer vremena
#include "PID.h" // Biblioteka za PID regulator
#include "TextLCD.h"// Biblioteka za LCD zaslon

#define AUTOMATIC 1
#define MANUAL    0
#define DIRECT  0
#define REVERSE  1
#define RATE 0.01
#define RATEISPIS 0.5
#define SLAVEADDRESS 0x4E // adresa LCD zaslona

// Konfiguracija potrebnih parametara
I2C i2c_lcd(p9,p10); // SDA linija, SCL linija
// I2C bus, PCF8574T adresa slavea, LCD tip(16x4)
TextLCD_I2C lcd(&i2c_lcd,SLAVEADDRESS,TextLCD::LCD16x4);
const int frekvencija = 50; // Frekvencija izmjenične struje, 50 Hz
InterruptIn ac_sin(p12, PullDown); // Digitalni ulaz(Interupt In) za detekciju sinusnog signala
DigitalOut buzzer(p5); // Izlaz za upravljanje pištalicom
DigitalOut led1(LED1); // Pali se ledina na frekvenciji od 100 Hz u trajanju 1 ms, sinus AC napona blizu nule
Serial pc(USBTX, USBRX); // Komunikacija s računalom
Timeout triggerAC; // Tajmer za detekciju  vremena kada se trjak može sigurno upaliti
Timeout response;// Tajmer za odgodu pokretana grijača ploče radi PWM-a
Timer debounce; // Tajmer za uklanjanje debounce efekta
Ticker ticker; // Tajmer za vrjeme uzorka za PID regulator
Ticker PrintTicker; // Definiran tajmer za slanje rezultata PID procesa na PC svakih 2s
Ticker ispis; // Tajmer za ispis na LCD zaslonu
bool nula_detektirana;
float histereza = 1.0; // Histereza, dozvoljeno odstupanje
float PID_max = 255;
float PID_min = 0;

// Ulazi i izlazi ploče za lemljenje
char dispcycle; // Stanja lemljenja, 7 ukupnih procesa
char const *lcd_status[]= {"Zagrijavanje",
                     "Namakanje",
                     "Porast temp.",
                     "Lemljenje",
                     "Lemljenje",
                     "Hladenje",
                     " KRAJ "
};
#define  PREDGRIJAVANJE 1
#define  NAMAKANJE 2
#define  PORAST_TEMPERATURE 3
#define  START_LEMLJENJA 4
#define  KRAJ_LEMLJENJA 5
#define  HLADENJE 6
#define  KRAJ 7
InterruptIn conf(p13);        // Digitalni ulaz za konfiguraciju parametara
InterruptIn pokr_zaus(p6);    // Digitalni ulaz za pokretanje ili zaustavljanje
DigitalIn ploca_plus(p28);  // Digitalni ulaz za povećanje temperature
DigitalIn ploca_minus(p27); // Digitalni ulaz za smanjivanje temperature
AnalogIn temp_ploce(p15);   // Analogni za signal termo elementa ploče
DigitalOut led2(LED2);      // Stanje grijača ploče, ledica LPC-a radi ako je grijač on
PwmOut grijac_ploce(p23);   // Pwm izlaz za upravljanje grijaćim elementom
// Koeficijenti Steinhart-Hartove jednadžbe
float A = -0.00317;
float B = 0.000798;
float C = -0.00000174;
// Varijable za reflow ploču
char status;           // "State machine" procesi za lemljenje putem ploče
float ADC_vrijednost;  // Vrijednost temperature ploče kao ADC vrijednost
float otpor;           // Vrijednost otpora za NTC termistor
float temp_analog;     // Analogna vrijednost temperature ploče
float temp;            // Trenutna temperatura ploče
float temp_ploca;
float temp_prije;      // Prethodna temperatura ploče
float t_start;           // Početna temperatura ploče
float preostalo_vrijeme; // Preostalo vrijeme zagrijavanja ploče
float t_set;             // Postavljena temperatura ploče
float t_proc;            // Procijenjena buduća temperatura ploče
int stopa_povecanja;            // od 1 do 5, °C po sekundi
int temperatura_predgrijavanja; // od 100 do 180, °C
int vrijeme_predgrijavanja;     // od 30 do 90, sekunda
int stopa_grijanja;             // od 1 do 10, °C po sekundi
int temperatura_lemljenja;      // od 120 do 230, °C
int vrijeme_lemljenja;          // od 30 do 90, sekunda
int stopa_pada;                 // od 1 do 10, °C po sekundi
//PID varijable za ploču
float Kp_ploca= 8.5;//2
float Ki_ploca = 0.25;//
float Kd_ploca = 2.83;//9
float PID_ploca;
// trenutna temperatura, PWM pin ploce, željena temperatura, Kp, Ki, Kd,
PID controller_ploca(&temp, &PID_ploca, &t_set, Kp_ploca, Ki_ploca, Kd_ploca, DIRECT);

// Ulazi i izlazi lemilice 858D
DigitalIn zrak_on(p7);     // Digitalni ulaz za pokretanje lemilice 858D;
InterruptIn zrak_plus(p30);       // Digitalni ulaz za povećanje temperature
InterruptIn zrak_minus(p29);      // Digitalni ulaz za smanjivanje temperature
AnalogIn temp_zrak(p17);        // Analogni ulaz za signal termoelementa 858D
AnalogIn ven_zrak(p19);         // Analogni ulaz za postavljanje brzine ventilatora
InterruptIn reed_prekidac(p11, PullUp); // Ulaz za upravljanje lemilice 858D
DigitalOut led3(LED3);          // Stanje grijača lem. 858D, označuje rad grijača
PwmOut grijac_zrak(p22);        // Pwm izlaz za upravljanje drivera trijaka lemilice 858D
PwmOut ventilator(p24);         // Pwm izlaz za upravljanje brzinom ventilatora
// Varijable lemilice 858D
float postotak_ventilatora; // Brzina ispuhivanja kao postotak
bool stanje_858D;        // Globalna varijabla stanja lemilice 858D
bool rucica_858D_podignuta = false;        // Globalna varijabla stanja lemilice 858D
float temp_858D;            // Trenutna temperatura lemilice Hakko 858D
float temp_zrak_set = 250;  // Postavljena temperatura lemilice Hakko 858D
float temp_zrak_set_max = 450.0; // Maksimalna temperatura za lemilicu 858D
float temp_zrak_set_min = 150.0; // Minimalna temperatura za lemilicu 858D
// samo za korištenje 4N25
//PID varijable za lemilicu 858D
float Kp_858D = 2;
float Ki_858D = 0.0025;
float Kd_858D = 9;
float PID_858D ;
// trenutna temperatura, PWM pin lemilice 907, željena temperatura, Kp, Ki, Kd,
PID controller_858D(&temp_858D, &PID_858D, &temp_zrak_set, Kp_858D, Ki_858D, Kd_858D, DIRECT);

// Ulazi i izlazi lemilice 907
DigitalIn lem_on(p8); // Digitalni ulaz za pokretanje lemilice 907;
InterruptIn lem_plus(p26);   // Digitalni ulaz za povećanje temperature
InterruptIn lem_minus(p25);  // Digitalni ulaz za smanjivanje temperature
AnalogIn temp_lem(p18);    // Analogni za signal termo elementa 907
DigitalOut led4(LED4);     // Stanje grijača ploče, označuje rad grijača
PwmOut grijac_lem(p21);    // Pwm izlaz za upravljanje grijaćim elementom
// Varijable lemilice Hakko 907
bool stanje_907;
float temp_907;             // Trenutna temperatura lemilice Hakko 907
float temp_lem_set = 200.0; // Postavljena temperatura lemilice Hakko 907
float temp_lem_set_max = 375.0; // Maksimalna temperatura za lemilicu 907
float temp_lem_set_min = 180.0; // Minimalna temperatura za lemilicu 907
//PID varijable za 907
float Kp_907 = 10;
float Ki_907 = 0.2857;
float Kd_907 = 7;
float PID_907;
// trenutna temperatura, PWM lemilice 907, željena temperatura, Kp, Ki, Kd,
PID controller_907(&temp_907, &PID_907, &temp_lem_set, Kp_907, Ki_907, Kd_907, DIRECT);

// Funkcija za ispis parametara lemilice 907 na računalu
void Ispis_parametara907() {
    pc.printf("Temp907      PID_suma     SetTemp907   Kp        Ki        Kd        vrijeme\r\n");
    pc.printf("%f, %f, %f, %f, %f, %f, %d \r\n",
    temp_907, PID_907, temp_lem_set, controller_907.GetKp(), controller_907.GetKi(), controller_907.GetKd(), millis());
}
// Funkcija za ispis parametara lemilice 858D na računalu
void Ispis_parametara858D() {
    pc.printf("Temp858D      PID_suma     SetTemp858D   Kp        Ki        Kd        vrijeme\r\n");
    pc.printf("%f, %f, %f, %f, %f, %f, %d \r\n",
    temp_858D, PID_858D, temp_zrak_set, controller_858D.GetKp(), controller_858D.GetKi(), controller_858D.GetKd(), millis());
}
// Funkcija za ispis parametara ploce na računalu
void Ispis_parametaraploca() {
    pc.printf("TempPloca      PID_suma     SetTempPloca   Kp        Ki        Kd        vrijeme\r\n");
    pc.printf("%f, %f, %f, %f, %f, %f, %d \r\n",
    temp, PID_ploca, t_set, controller_ploca.GetKp(), controller_ploca.GetKi(), controller_ploca.GetKd(), millis());
}
// Funkcija za izračun temperature u stupnjevima
void ucitaj_temperaturu() {
    // jednadžba pravca kroz dvije točke
    // temperatura lemilice 907
    long int tem907;
    long int d;
    int e;
    d = 0;
    // 500 puta čita temperaturu i daje srednju vrijednost
    for (e=1; e <= 500; e++) {
        tem907 = temp_lem.read() * 1041 - 130;
        d += tem907;
    }
    temp_907 = d/500;
    //temp_907 = temp_lem.read() * 1041 - 130;
    // temperatura lemilice 858D
    long int tem858;
    long int f;
    int g;
    f = 0;
    for (g=1; g <= 500; g++) {
        tem858 = temp_zrak.read() * 580 - 62;
        f += tem858;
    }
    temp_858D = f/500;
    postotak_ventilatora = 100* (0.1 + (0.9* ven_zrak.read()));
    // temperatura ploče,  Steinhart-Harta jednadžba
    temp_ploca = temp_ploce.read() * 3.3; // ako je temp_ploce = 1 lemilica 907 nije priključena
    long int tem12;
    long int h;
    int k;
    h = 0;
    for (k=1; k <= 500; k++) {
    tem12 = temp_ploce.read() * 4095;
    h += tem12;
    }
    temp_analog =h/500;
    temp_analog = temp_ploce.read() * 4095;
    ADC_vrijednost = ((temp_analog * 3.3) / 4095);
    otpor = log(((3.3 * (10 / ADC_vrijednost))-10)*1000);
    temp = ((1/(A + (B * otpor)+(C * otpor * otpor * otpor)))-273.15);
    // kalibracija temperature
    temp = 1.01956 * temp - 0.296055;
}
// Funkcija za isključivanje spremnosti drivera za trijak
void iskljucivanje() {
    nula_detektirana = false;
    led1 = 0; // Povratna informacija kako signal 
}
// Funkcija za upravljanje grijača, izmjenični napon raste s 0.7 V
// Služi za pokretanje trijaka s pri određenom naponu(fazi) za optokapler 4N25
// takt detektiranja iznosi 100 Hz zbog punovalnog ispravljača
void detekcija(){
    nula_detektirana = true;
    led1 = 1; // Povratna informacija za detekciju izmjeničnog napona u 0.7 V
    // isključivanje grijača nakon timeouta od 8 ms, potrebna nova detekcija napona u "nuli" za ponovno postavljanje
    // nakon 8 ms driver ne smije biti pokrenut kako ne bi došlo do izobličenja napona
    triggerAC.attach(&iskljucivanje,(1/(2 * frekvencija)));
}
// Funkcija za pokretanja grijača ploče s odgodom
void blink(){
    grijac_ploce = 0.1;
}
// Funkcija za rad pištalice, zvučni signal u trajanju 200 ms
void buzzer_(){
    buzzer.write(1);
    wait(0.2);
    buzzer.write(0);
}
// Funkcije za postavljanje setpoint temperature za 907 i 858D
void povecaj_zrak() {
    buzzer_();// zvučni signal koji informira o pritisku tipkala i promijeni željenje temperature
    temp_zrak_set = temp_zrak_set + 5; // Željena temperatura raste za vrijednost 5
    // Ispitivanje dozvoljenog raspona radi zaštite od pregrijavanja
    if (temp_zrak_set > temp_zrak_set_max){
        temp_zrak_set = temp_zrak_set_max;
    }
    debounce.reset();// resetiranje debounce tajmera
}
void smanji_zrak() {
    buzzer_();// zvučni signal koji informira o pritisku tipkala i promijeni željenje temperature
    temp_zrak_set = temp_zrak_set - 5; // Željena temperatura raste za vrijednost 5
    // Ispitivanje dozvoljenog raspona radi zaštite od pregrijavanja
    if (temp_zrak_set < temp_zrak_set_min){
        temp_zrak_set = temp_zrak_set_min;
    }
    debounce.reset();// resetiranje debounce tajmera
}
void povecaj_lem() {
    buzzer_();// zvučni signal koji informira o pritisku tipkala i promijeni željenje temperature
    temp_lem_set = temp_lem_set + 5; // Željena temperatura raste za vrijednost 5
    // Ispitivanje dozvoljenog raspona radi zaštite od pregrijavanja
    if (temp_lem_set > temp_lem_set_max){
        temp_lem_set = temp_lem_set_max;
    }
    debounce.reset(); // resetiranje debounce tajmera
}
// Funkcija smanjivanja željenje temperature unutar dozvoljenog područja
void smanji_lem() {
    buzzer_();// zvučni signal koji informira o pritisku tipkala i promijeni željenje temperature
    temp_lem_set = temp_lem_set - 5;
    if (temp_lem_set < temp_lem_set_min){
        temp_lem_set = temp_lem_set_min;
    }
    debounce.reset();// resetiranje debounce tajmera
}
// Funkcija za iskljucivanje lemilice 907
void lemilica_907_off(){
    grijac_lem = 0.00f;//0% duty cycle,grijač isključen
    led4 = 0; // grijač lemilice 907 je isključen
}
// Funkcija za pokretanje lemilice 907
void lemilica_907_on(){
    if (temp_907 < temp_lem_set) {
        // Funkcija uključivanja grijača lemilice Hakko 907
        controller_907.Compute(); // Obrada PID petlje
        // upravljanje grijača lemilice 907
        if(PID_907 > PID_max) {
            PID_907 = PID_max;
        } else if (PID_907 < PID_min) {
            PID_907 = PID_min;
        }
        // grijac_lem = float(PID_907/PID_max); // Poslana PWM vrijednost skalirana od 0 do 1,0 prema zahtjevima mbed-a
        grijac_lem = 1.0;
        led4 = 1; // ledica 4 je uklju. što znači grijač lemilice 907 je uključe
        } else if (temp_907 > temp_lem_set){
            grijac_lem = 0;//0% duty cycle,grijač isključen
            led4 = 0; // grijač lemilice 907 je isključen
        }
}
// Funkcija za iskljucivanje lemilice 858D
void lemilica_858D_off(){
    led3 = 0; // grijač lemilice 907 je isključen
    grijac_zrak = 0.00f;//0% duty cycle,grijač isključen
    if ((temp_858D > 50) && (rucica_858D_podignuta == false)) {
        ventilator = 1.00f;// pokrenuti ventilator na 100 % PWM-a radi hlađenja grijača
    }
}
// Funkcija za postavljena stanja ručice lemilice 858D
void magnet(){
    if (rucica_858D_podignuta == false){
        rucica_858D_podignuta = true;
    } else {
    rucica_858D_podignuta = false; // ručica postavljena na predviđeni stalak
    }  
}
// Funkcija za pokretanje lemilice 858D
void lemilica_858D_on() {
    if(rucica_858D_podignuta == true){
        // kada se podigne lemilica 858D, ventilator radi na 20 % PWM, a grijač do postavljene temperature
        // pošto sam prema orijentaciji pogrešno postavio potentiometar, htio sam da prema okretanju
        // u smjeru kazaljke na satu raste brzina ventilatora
        ventilator = (0.1 + 0.9*ven_zrak.read()); // minimalni PWM iznosi 10 %
        PrintTicker.attach(&Ispis_parametara858D,RATEISPIS);
        // upravljanje driverom trijaka lemilice 858D
        if (temp_858D < (temp_zrak_set - histereza) && rucica_858D_podignuta == true){
            led3 = 1; // ledica 3 na mikrokontoleru je uključena, grijač zraka je uključen
            // pošto se koristi MOC3061 nema potrebe za detekcijom sinusnog signala
            // navedeni optički sprežnik radi samostalnu detekciju sinusnog signala u nuli
            grijac_zrak.write(1.00f); // ON/OFF regulacija
        } else if(temp_858D > temp_zrak_set - histereza){
            led3 = 0;//ledica 3 je islju. što znači grijač zraka je isključen
            grijac_zrak = 0.00f;//0% duty cycle,grijač isključen
        }
        // zaštita od pregrijavanja ručice 858D, ventilator nastoji ispuhati (ohladiti grijač) do 50 stupnjeva Cezlijusa
        // u obzir uzet slučaj isklkučivanja na prekidaču, jedino što može prekinuti proces hlađenja je isključivanje iz utičnice
    } else if (rucica_858D_podignuta == false){
        lemilica_858D_off();
    }
}
// Funkcija za postavljena stanja, u slučaju da nije pokrenuta konfiguracija koriste se sljedeće varijable
void Default_stanja() {
    // Varijable za "defaulti" profil
    stopa_povecanja = 4;
    temperatura_predgrijavanja = 150;
    vrijeme_predgrijavanja = 60;
    stopa_grijanja = 10;
    temperatura_lemljenja = 200;
    vrijeme_lemljenja = 30;
    stopa_pada = 4;
}
// Funkcija za postavljanje parametra za lemljenje putem ploče unutra dozvoljenog raspona
void konfiguracija(int *vrijednost, int min_val, int min_max) {
    int v; // lokalna varijabla
    v = *vrijednost;
    do {
        ucitaj_temperaturu();
        if (temp_907 < temp_lem_set_max && lem_on == 0||temp_907 > temp_lem_set_max && lem_on == 0){
            lcd.locate (4,0);
            lcd.printf ("907: OFF");
        }if (temp_907 > 50 && temp_907 < temp_lem_set_max && lem_on == 0){
            lcd.locate (4,0);
            lcd.printf ("907:!%.f C",temp_907);
        }if(temp_907 < 35 && lem_on == 0){
            lcd.locate (4,0);
            lcd.printf ("907: Ready");
        }if(temp_907 > 0 && temp_907 < temp_lem_set_max && lem_on == 1) {
            lcd.locate (1,0);
            lcd.printf ("907:%.f",temp_907);
            lcd.locate (9,0);
            lcd.printf("/%.f C",temp_lem_set);
        } if (temp_858D <= temp_zrak_set_max && zrak_on == 0 && rucica_858D_podignuta == false||temp_858D < 0){
            lcd.locate (3,1);
            lcd.printf ("858D: OFF");
        }if (temp_858D < temp_zrak_set_max && zrak_on == 1 && rucica_858D_podignuta == false
            ||temp_858D < temp_zrak_set_max && zrak_on == 0 && rucica_858D_podignuta == true){
            lcd.locate (3,1);
            lcd.printf ("858D: Ready");
        } if (temp_858D > 50 && zrak_on == 0 && rucica_858D_podignuta == false){
            lcd.locate (3,1);
            lcd.printf ("858D:!%.f C",temp_858D);
        } if (temp_858D > 0 &&zrak_on == 1 && rucica_858D_podignuta == true) {
            lcd.locate(0,1);
            lcd.printf("858D:%.f",temp_858D);
            lcd.locate(9,1);
            lcd.printf("/%.f",temp_zrak_set);
            lcd.locate(13,1);
            lcd.printf("%.f%",postotak_ventilatora);
        }
        lcd.locate(13,2);
        lcd.printf("%d",v);
        lcd.locate(0,3);
        lcd.printf("[next][-][+]");
        debounce.start();
        if (ploca_minus == 1 && debounce.read_ms() > 40) {
            buzzer_();
            debounce.reset();
            v--;
            if (v < min_val) v = min_val;
        }
        if (ploca_plus == 1 && debounce.read_ms() > 40) {
            buzzer_();
            debounce.reset();
            v++;
            if (v > min_max) v = min_max;
        }
    } while (pokr_zaus != 1);
    if (debounce.read_ms() > 200) {
    *vrijednost = v;
    }
    lcd.cls();
    debounce.reset();
}
// Funkcija za stanja procesa, prijelazan na sljedeći proces
void osvjezi_status() {
    if (status == 0) return;
    switch (status) {
        case PREDGRIJAVANJE:
            t_set = t_set + stopa_povecanja;
            if (t_set > temperatura_predgrijavanja) {
                status = NAMAKANJE;
                dispcycle = 1;
            }
            break;
        case NAMAKANJE:
            if ((temp + histereza) > temperatura_predgrijavanja) {
                preostalo_vrijeme = vrijeme_predgrijavanja;
                status = PORAST_TEMPERATURE;
                dispcycle = 1;
            }
            break;
        case PORAST_TEMPERATURE:
            if (preostalo_vrijeme == 0) {
                preostalo_vrijeme = (temperatura_lemljenja - temperatura_predgrijavanja)/stopa_grijanja;
                status = START_LEMLJENJA;
                dispcycle = 1;
            }
            break;
        case START_LEMLJENJA:
            t_set = t_set + stopa_grijanja;
            if (t_set > temperatura_lemljenja) {
                status = KRAJ_LEMLJENJA;
                dispcycle = 1;
            }
            break;
        case KRAJ_LEMLJENJA:
            if ((temp + histereza) > temperatura_lemljenja) {
                preostalo_vrijeme = vrijeme_lemljenja;
                status = HLADENJE;
                dispcycle = 1;
            }
            break;
        case HLADENJE:
            if (preostalo_vrijeme == 0) {
                preostalo_vrijeme = ((temperatura_lemljenja - t_start))/stopa_pada;
                status = KRAJ;
                dispcycle = 1;
            }
            break;
        case KRAJ:
            t_set = t_set - stopa_pada;
            if (t_set < t_start) {
                t_set = temp;
                status = 0;
                dispcycle = 1;
            }
            break;
        default:
            status = 0;
    }
}
// Funkcija za pokretanje automatiziranog procesa ploče
void Run_mod() {
    if(debounce.read_ms() > 100) {
        status = 1;
        dispcycle = 0;
        t_set = temp;
        ucitaj_temperaturu(); // nova temperatura
        t_start = temp;
        preostalo_vrijeme = (temperatura_predgrijavanja - temp)/stopa_povecanja;
        preostalo_vrijeme = 100 * preostalo_vrijeme;
        while (pokr_zaus == 0){
            //wait_ms(10);
            }
            do {
            temp_prije = temp;
            ucitaj_temperaturu(); // nova temperatura 
            // procjena buduće temperature uz pomoć PID-a
            t_proc = (10*temp - (temp - temp_prije)*10)/10;
            ucitaj_temperaturu();
            // ispis na zaslonu
            lcd.cls();
            if (temp_907 < temp_lem_set_max && lem_on == 0||temp_907 > temp_lem_set_max && lem_on == 0){
            lcd.locate (4,0);
            lcd.printf ("907: OFF");
            if (temp_907 > 50 && temp_907 < temp_lem_set_max && lem_on == 0){
                lcd.locate (4,0);
                lcd.printf ("907:!%.f C",temp_907);
            }if(temp_907 < 35 && lem_on == 0){
                lcd.locate (4,0);
                lcd.printf ("907: Ready");
            }if(temp_907 > 0 && temp_907 < temp_lem_set_max && lem_on == 1) {
                lcd.locate (1,0);
                lcd.printf ("907:%.f",temp_907);
                lcd.locate (9,0);
                lcd.printf("/%.f C",temp_lem_set);
            } if (temp_858D <= temp_zrak_set_max && zrak_on == 0 && rucica_858D_podignuta == false||temp_858D < 0){
                lcd.locate (3,1);
                lcd.printf ("858D: OFF");
            }if (temp_858D < temp_zrak_set_max && zrak_on == 1 && rucica_858D_podignuta == false
                ||temp_858D < temp_zrak_set_max && zrak_on == 0 && rucica_858D_podignuta == true){
                lcd.locate (3,1);
                lcd.printf ("858D: Ready");
            } if (temp_858D > 50 && zrak_on == 0 && rucica_858D_podignuta == false){
                lcd.locate (3,1);
                lcd.printf ("858D:!%.f C",temp_858D);
            } if (temp_858D > 0 &&zrak_on == 1 && rucica_858D_podignuta == true) {
                lcd.locate(0,1);
                lcd.printf("858D:%.f",temp_858D);
                lcd.locate(9,1);
                lcd.printf("/%.f",temp_zrak_set);
                lcd.locate(13,1);
                lcd.printf("%.f%",postotak_ventilatora);
            }
            lcd.locate(0,2);
            lcd.printf("Temp:%.1f C", temp);
            lcd.locate(12,2);
            lcd.printf("%d/7",status);
            lcd.locate(0,3);
            lcd.printf(lcd_status[status-1]);
             wait(1);
            if (preostalo_vrijeme != 0) preostalo_vrijeme--;
            debounce.reset();
            if ((pokr_zaus == 1) && debounce.read_ms() > 50) {
                status = 0;
                iskljucivanje();
                }
            osvjezi_status();
            t_set = temp;
            // upravljanje grijača ploče
            controller_ploca.Compute(); // Obrada PID petlje
            if (t_proc < t_set && nula_detektirana == true){
                if(PID_ploca > PID_max) {
                    PID_ploca = PID_max;
                } else if(PID_ploca < PID_min) {
                    PID_ploca = PID_min;
                }
                /* uvodi se kašnjenje, ako je potreban PWM od 60%, potrebno je
                pokrenuti grijač 4 ms nakon detekcije
                */
                if (nula_detektirana== true){
                    response.attach(&blink,(1.01- float(PID_ploca/PID_max)/10));
                    led2 = 1; // grijač ploče je uključen
                }
            }
            if (t_proc > t_set){
                grijac_ploce.write(0.00f);
                led2 = 0; // grijač ploče je isključen
            }
            // ispisivanje na zaslonu, prijelaz teksta
            dispcycle = 1 - dispcycle;
            }
            }
            while (status != 0);
    }
    debounce.reset(); 
}
// Funkcija za izbor parametara ploče, pritisnom na "zelenu tipkalo" prijelazi se na novi parametar
void Konfiguracijski_Mod() {
    if(debounce.read_ms() > 20) {
        ucitaj_temperaturu();
        lcd.cls();
        if (temp_907 < temp_lem_set_max && lem_on == 0||temp_907 > temp_lem_set_max && lem_on == 0){
            lcd.locate (4,0);
            lcd.printf ("907: OFF");
        }if (temp_907 > 50 && temp_907 < temp_lem_set_max && lem_on == 0){
            lcd.locate (4,0);
            lcd.printf ("907:!%.f C",temp_907);
        }if(temp_907 < 35 && lem_on == 0){
            lcd.locate (4,0);
            lcd.printf ("907: Ready");
        }if(temp_907 > 0 && temp_907 < temp_lem_set_max && lem_on == 1) {
            lcd.locate (1,0);
            lcd.printf ("907:%.f",temp_907);
            lcd.locate (9,0);
            lcd.printf("/%.f C",temp_lem_set);
        } if (temp_858D <= temp_zrak_set_max && zrak_on == 0 && rucica_858D_podignuta == false||temp_858D < 0){
            lcd.locate (3,1);
            lcd.printf ("858D: OFF");
        }if (temp_858D < temp_zrak_set_max && zrak_on == 1 && rucica_858D_podignuta == false
            ||temp_858D < temp_zrak_set_max && zrak_on == 0 && rucica_858D_podignuta == true){
            lcd.locate (3,1);
            lcd.printf ("858D: Ready");
        } if (temp_858D > 50 && zrak_on == 0 && rucica_858D_podignuta == false){
            lcd.locate (3,1);
            lcd.printf ("858D:!%.f C",temp_858D);
        } if (temp_858D > 0 &&zrak_on == 1 && rucica_858D_podignuta == true) {
            lcd.locate(0,1);
            lcd.printf("858D:%.f",temp_858D);
            lcd.locate(9,1);
            lcd.printf("/%.f",temp_zrak_set);
            lcd.locate(13,1);
            lcd.printf("%.f%",postotak_ventilatora);
        }
        int i;
        for (i = 1; i <= 7; i++) {
            switch (i) {
                case 1:
                    lcd.locate(0,2);
                    lcd.printf("Stopa poveca:");
                    konfiguracija(&stopa_povecanja,1,10);
                    break;
                case 2:
                    lcd.locate(0,2);
                    lcd.printf("Temp predgri:");
                    konfiguracija(&temperatura_predgrijavanja,100,180);
                    break;
                case 3:
                    lcd.locate(0,2);
                    lcd.printf("Vrij predgri:");
                    konfiguracija(&vrijeme_predgrijavanja,30,90);
                    break;
                case 4:
                    lcd.locate(0,2);
                    lcd.printf("Stopa grija:");
                    konfiguracija(&stopa_grijanja,1,20);
                    break;
                case 5:
                    lcd.locate(0,2);
                    lcd.printf("Temp reflow:");
                    konfiguracija(&temperatura_lemljenja,120,230);
                    break;
                case 6:
                    lcd.locate(0,2);
                    lcd.printf("Vrij reflow:");
                    konfiguracija(&vrijeme_lemljenja,30,90);
                    break;
                case 7:
                    lcd.locate(0,2);
                    lcd.printf("Stopa pada:");
                    konfiguracija(&stopa_pada,1,5);
                    break;
            }
        }
    }
    debounce.reset();
}

// Glavni dio programa
int main() {
    startMillis(); // Inicijalizacija tajmera
    debounce.start();
    pc.baud(9600); // Ispis na ekranu
    controller_907.SetSampleTime(1); // PID proces lemilice 907 koji radi s brzinom uzrokovanja od 10 ms
    controller_858D.SetSampleTime(1); // PID proces lemilice 858D koji radi s brzinom uzrokovanja od 10 ms
    controller_ploca.SetSampleTime(1); // PID proces ploče koji radi s brzinom uzrokovanja od 10 ms
    // iako LPC1768 posjeduje 6 PWM izlaza oni posjeduju zajednički period :(
    iskljucivanje(); // Driveri za upravljanje trijcima su isključeni
    grijac_lem.period(1);
    grijac_ploce.period(0.010f);
    grijac_zrak.period(0.010f);
    ventilator.period(0.010f); // duty cycle ovisi o potenciometru,vrijednosti 0.0 - 1.0
    lcd.setBacklight(TextLCD::LightOn); // poziv za osvjetljenje zaslona

    ac_sin.mode(PullNone);
    ac_sin.rise(&detekcija);
    
    controller_907.SetMode(AUTOMATIC); // Uključivanje PID regulator
    lem_plus.rise(&povecaj_lem);
    lem_minus.rise(&smanji_lem);
    lem_on.mode(PullDown);

    controller_858D.SetMode(AUTOMATIC); // Uključivanje PID regulator
    reed_prekidac.mode(PullDown);
    reed_prekidac.rise(&magnet);
    zrak_plus.rise(&povecaj_zrak);
    zrak_minus.rise(&smanji_zrak);
    zrak_on.mode(PullDown);

    controller_ploca.SetMode(AUTOMATIC); // Uključivanje PID regulator
    Default_stanja();
    lcd.cls();
    while (1){
        lcd.cls();
        if (reed_prekidac.read() == 1){
            rucica_858D_podignuta = true;
        }else {
            rucica_858D_podignuta = false;
        }
        ucitaj_temperaturu();
        if (temp_907 < temp_lem_set_max && lem_on == 0||temp_907 > temp_lem_set_max && lem_on == 0){
            lcd.locate (4,0);
            lcd.printf ("907: OFF");
        }if (temp_907 > 50 && temp_907 < temp_lem_set_max && lem_on == 0){
            lcd.locate (4,0);
            lcd.printf ("907:!%.f C",temp_907);
        }if(temp_907 < 35 && lem_on == 0){
            lcd.locate (4,0);
            lcd.printf ("907: Ready");
        }if(temp_907 > 0 && temp_907 < temp_lem_set_max && lem_on == 1) {
            lcd.locate (1,0);
            lcd.printf ("907:%.f",temp_907);
            lcd.locate (9,0);
            lcd.printf("/%.f C",temp_lem_set);
        } if (temp_858D <= temp_zrak_set_max && zrak_on == 0 && rucica_858D_podignuta == false||temp_858D < 0){
            lcd.locate (3,1);
            lcd.printf ("858D: OFF");
        }if (temp_858D < temp_zrak_set_max && zrak_on == 1 && rucica_858D_podignuta == false
            ||temp_858D < temp_zrak_set_max && zrak_on == 0 && rucica_858D_podignuta == true){
            lcd.locate (3,1);
            lcd.printf ("858D: Ready");
        } if (temp_858D > 50 && zrak_on == 0 && rucica_858D_podignuta == false){
            lcd.locate (3,1);
            lcd.printf ("858D:!%.f C",temp_858D);
        } if (temp_858D > 0 &&zrak_on == 1 && rucica_858D_podignuta == true) {
            lcd.locate(0,1);
            lcd.printf("858D:%.f",temp_858D);
            lcd.locate(9,1);
            lcd.printf("/%.f",temp_zrak_set);
            lcd.locate(13,1);
            lcd.printf("%.f%",postotak_ventilatora);
        }
        lcd.locate (3,2);
        lcd.printf("Temp: %.f", temp);
        lcd.locate (13,2);
        lcd.printf("C");
        // Izbornik za pokretanje i konfiguraciju
        lcd.locate(0,3);
        lcd.printf(" [CONF] [START] ");
        wait(1);
        if (conf == 1){
            Konfiguracijski_Mod();
        }if (pokr_zaus == 1){
            Run_mod();
        }if(lem_on == 1){
            lemilica_907_on();
        }if(lem_on == 0){
            lemilica_907_off();
        }if ((temp_858D > 0 &&zrak_on == 1 && rucica_858D_podignuta == true)){
            lemilica_858D_on();
        }if (zrak_on == 0||temp_858D <= 0){
            lemilica_858D_off();
        }
    }
}

